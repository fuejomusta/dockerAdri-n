CREATE TABLE modulos (
	id INT AUTO_INCREMENT PRIMARY KEY,
	nombre VARCHAR(75) NOT NULL
);

INSERT INTO modulos (nombre) VALUES
('cliente'),
('interfaces'),
('despliegue'),
('ingles'),
('programación');